from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

def is_safe(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            return {'safe': True, 'message': 'Website is safe to shop from.'}
        else:
            return {'safe': False, 'message': 'Website may not be safe to shop from.'}
    except Exception as e:
        return {'safe': False, 'message': f'Error checking website safety: {str(e)}'}

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/check', methods=['POST'])
def check():
    data = request.get_json()
    url = data.get('url', '')
    if url:
        return jsonify(is_safe(url))
    else:
        return jsonify({'safe': False, 'message': 'Invalid URL'})

if __name__ == '__main__':
    app.run(debug=True)
